# Color Palette Explorer - Deployment Guide

## Project Overview
Color Palette Explorer is a visually-driven website that helps users explore, mix, and visualize colors in creative ways. The site features a modern glassmorphism design with interactive elements and animations.

## Features
- **Home Page**: Visually appealing landing page with stylish design and eye-catching graphics
- **Color Mix Tool**: Interactive tool to mix and match individual colors into palettes
- **Trending Palettes**: Curated color combinations selected by designers
- **About Page**: Information about the creator, Yota Kaizaki
- **Single Colors**: Browse individual color swatches with detailed information
- **All Palettes**: View all available color palettes
- **Favorites**: Save palettes locally on your device
- **Visualization Modes**:
  - Fluid Waves: Abstract wave animations using selected palette
  - Glass Morphism: Semi-transparent UI elements with color integration
  - Gradient Blend: Smooth gradient transitions across palette colors
  - Neon Glow: High-contrast neon-themed visualizer

## Project Structure
```
color_palette_explorer/
├── index.html              # Main HTML file
├── css/
│   ├── styles.css          # Main stylesheet
│   ├── additional-styles.css # Styles for trending, about, and visualizations
│   └── mobile.css          # Mobile-specific styles
├── js/
│   ├── data.js             # Color and palette data
│   ├── script.js           # Main JavaScript functionality
│   └── visualizations.js   # Visualization modes implementation
├── images/                 # Image assets (if any)
└── assets/                 # Additional assets (if any)
```

## Deployment to GitHub Pages

### Option 1: Using GitHub Desktop
1. Create a new repository on GitHub
2. Open GitHub Desktop and clone the repository to your local machine
3. Copy all files from the `color_palette_explorer` folder to your local repository folder
4. Commit the changes with a message like "Initial commit"
5. Push the changes to GitHub
6. Go to your repository on GitHub
7. Navigate to Settings > Pages
8. Under "Source", select "main" branch and click Save
9. Your site will be published at `https://[your-username].github.io/[repository-name]/`

### Option 2: Using GitHub Web Interface
1. Create a new repository on GitHub
2. Click on "uploading an existing file"
3. Drag and drop all files from the `color_palette_explorer` folder or use the file selector
4. Commit the changes
5. Navigate to Settings > Pages
6. Under "Source", select "main" branch and click Save
7. Your site will be published at `https://[your-username].github.io/[repository-name]/`

## Local Development
To run the site locally:
1. Navigate to the project folder
2. Open `index.html` in your browser

## Customization
- To add new colors or palettes, edit the arrays in `js/data.js`
- To modify the visualizations, edit `js/visualizations.js`
- To change the styling, edit the CSS files in the `css` folder

## Browser Compatibility
The site is compatible with modern browsers including:
- Chrome
- Firefox
- Safari
- Edge

## Mobile Responsiveness
The site is fully responsive and works on all device sizes. On mobile devices, colors are arranged with 3 colors per line for better visual appeal and usability.
